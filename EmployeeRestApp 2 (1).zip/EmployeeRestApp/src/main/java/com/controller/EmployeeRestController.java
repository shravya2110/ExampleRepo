package com.controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import com.model.Company;
import com.model.Employee;
import java.util.List;


@RestController
public class EmployeeRestController {
    @GetMapping("/employees")
    public List<Employee> getAllEmployees() {
        Company company = new Company();
        return company.getEmpList();
    }
}